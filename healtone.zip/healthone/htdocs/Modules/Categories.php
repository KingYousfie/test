<?php
// TODO Zorg dat de methodes goed ingevuld worden met de juiste queries.
function getCategories()
{
    
}

function getCategoryName(int $id)
{
    
}
